#ifndef _ETHERCAT_MASTER_H
#define _ETHERCAT_MASTER_H

// Standard headers
#include <stdio.h>
#include <string.h>
#include <inttypes.h>

// Module headers
#include "ethercat.h"

#endif /* _ETHERCAT_MASTER_H */
